try the link !!
amazon-clone!!
https://vivekkaannamreddi.github.io/amazon-clone/p1.html
